﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web.Script.Services;

namespace VLIB_WS_SOAP_Caching {
     [ServiceContract]
    public interface IVlibCacheService {

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<JCDecaux_API.Contract> GetContracts();

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<JCDecaux_API.Station> GetStations();

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        bool fullFeed();

    }
}
