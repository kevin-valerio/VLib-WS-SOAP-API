﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using VLIB_WS_SOAP_Caching;

namespace JCD_WS_CACHE {
    class Program {
        static void Main(string[] args) {
            /*   String __URL__ = "http://localhost:8090/JCD_SOAP_CACHE/API"; 
               ServiceHost host = new ServiceHost(typeof(VlibCacheService), new Uri(__URL__));

               host.AddServiceEndpoint(typeof(IVlibCacheService), new WSHttpBinding(), "");
               ServiceEndpoint se = host.AddServiceEndpoint(typeof(IVlibCacheService), new WebHttpBinding(), "http://localhost:8090/JCD_SOAP_CACHE/REST", 
                   new Uri("http://localhost:8090/JCD_SOAP_CACHE/REST"));
               se.EndpointBehaviors.Add(new WebHttpBehavior());
               ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
               smb.HttpGetEnabled = true;
               host.Description.Behaviors.Add(smb);
               host.Description.Behaviors.Remove(typeof(ServiceDebugBehavior));
               host.Description.Behaviors.Add(new ServiceDebugBehavior { IncludeExceptionDetailInFaults = true });
               host.Open();

               Console.WriteLine("Service is host at " + DateTime.Now.ToString());
               Console.WriteLine("URL : " + __URL__);
               Console.WriteLine("Host is running... Press <Enter> key to stop");
               Console.ReadLine(); */

            ServiceHost serviceHost = new ServiceHost(typeof(VlibCacheService));
            serviceHost.Open();

            Console.WriteLine("Server : CACHE");
            Console.WriteLine("Service is host at " + DateTime.Now.ToString());
            Console.WriteLine("URL : " + "http://localhost:8090/JCD_SOAP_CACHE/API");
            Console.WriteLine("Host is running... Press <Enter> key to stop");
            Console.ReadLine();
        }
    }
}
