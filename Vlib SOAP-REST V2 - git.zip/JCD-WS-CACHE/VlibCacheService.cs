﻿using JCDecaux_API;
using System;
using System.Collections.Generic;

namespace VLIB_WS_SOAP_Caching {
    /// <summary>
    /// Ce web service offre une interface SOAP/REST 
    /// qui permet à chaque application d'obtenir les datas de l'API JCDecaux
    /// stockées en cache. Cela permet deux choses
    /// 1. Ne pas "spammer" le serveur JCDecaux de requetes "inutiles"
    /// 2. Pouvoir séparer la responsabilité de chaque WebApp. On pourrait ainsi
    /// imaginer d'autres WebApp qui utiliserai ce service de caching.
    /// </summary>
    public class VlibCacheService : IVlibCacheService {
      
        private const string API_KEY = "8542dbcf60bced995bb88e18829cc836c7ec5afe";

        public VlibCacheService() {
            fullFeed();
        }
        public List<Contract> GetContracts() {
            return JCDecaux_Contracts_API.getInstance.Contracts;
        }
        public List<Station> GetStations() {
            return JCDecaux_Stations_API.getInstance.Stations;
        }

        /// <summary>This method feed all the variable, so you can work with it.</summary>
        public bool fullFeed() {

            /*This is the caching system. We get all the data one for all, and store it into our JCDecaux instance. 
            Then we just need to call the following method in order to get data, 
            so the real JCDecaux servers won't be "spammed" of requests.*/
             
            JCDecaux_Contracts_API.getInstance.setAPI(API_KEY);
            JCDecaux_Stations_API.getInstance.setAPI(API_KEY);
            JCDecaux_Stations_API.getInstance.setCity(""); //no city, we want everything

            JCDecaux_Stations_API.getInstance.feedStations();
            JCDecaux_Contracts_API.getInstance.feedContracts();
           
            return true;
        }
    }
}
