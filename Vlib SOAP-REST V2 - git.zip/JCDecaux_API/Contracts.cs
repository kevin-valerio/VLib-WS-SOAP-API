﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace JCDecaux_API {
     
    [DataContractAttribute]
    public class Contract {

        [DataMemberAttribute]
        [JsonProperty("name")]
        public string Name { get; set; }
        [DataMemberAttribute]
        [JsonProperty("commercial_name")]
        public string CommercialName { get; set; }
        [DataMemberAttribute]
        [JsonProperty("cities")]
        public List<String> Cities { get; set; }
        [DataMemberAttribute]
        [JsonProperty("country_code")]
        public string CountryCode { get; set; }


    }

}
