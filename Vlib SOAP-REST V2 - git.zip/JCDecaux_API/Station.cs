﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace JCDecaux_API {
    [DataContractAttribute]

    public class Position {
     
        public Position(double lat, double lng) {
            this.lat = lat;
            this.lng = lng;
        }
        [DataMemberAttribute] 
        [JsonProperty("lat")]
        public double lat { get; set; }

        [DataMemberAttribute]
        [JsonProperty("lng")]
        public double lng { get; set; }
  
        public override string ToString() {
            return lng + ", " + lat;
        }
    }
    [DataContractAttribute]

    public class Station {
        public Station(Position position) {
            this.position = position;
        }



        /// <summary>
        /// Numeo de station
        /// </summary>
        /// 
        [JsonProperty("number")]
        [DataMemberAttribute]

        public int number { get; set; }
                
        /// <summary>
        /// Ville de la station
        /// </summary>
        [JsonProperty("contract_name")]
        [DataMemberAttribute]

        public string contract_name { get; set; }

        [JsonProperty("name")]
        [DataMemberAttribute]

        public string name { get; set; }

        [JsonProperty("address")]
        [DataMemberAttribute]

        public string address { get; set; }

        [JsonProperty("position")]
        [DataMemberAttribute]

        public Position position { get; set; }

        [JsonProperty("banking")]
        [DataMemberAttribute]

        public bool banking { get; set; }

        [JsonProperty("bonus")]
        [DataMemberAttribute]

        public bool bonus { get; set; }

        [JsonProperty("bike_stands")]
        [DataMemberAttribute]

        public int bike_stansd { get; set; }

        [JsonProperty("available_bike_stands")]
        [DataMemberAttribute]

        public int available_bike_stands { get; set; }

        [JsonProperty("available_bikes")]
        [DataMemberAttribute]

        public int available_bikes { get; set; }

        [JsonProperty("status")]
        [DataMemberAttribute]

        public string status { get; set; }

        [JsonProperty("last_update")]
        [DataMemberAttribute]

        public long last_update { set; get; } 
         
       

    }

}
