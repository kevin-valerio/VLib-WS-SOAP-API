﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using JCDecaux_API;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using VLib_Client.VLibSoap;
using VLib_WSSOAP_API;

namespace VLib_Client {
    public partial class Form1 : Form {
        VLibSoapServiceClient SOAPClient = new VLibSoapServiceClient();
        RESTClient rESTClient = new RESTClient();
        Timer refresher = new Timer();

        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            SOAPClient.Open();
            refreshData();
            refresher.Interval = 60000;
            refresher.Tick += new EventHandler(refreshDataTimerHandler);
            refresher.Enabled = true;
        }

        private void refreshDataTimerHandler(object Sender, EventArgs e) {
            refreshData();
        }

        private void refreshData() {
            if (isSOAP.Checked) {
                SOAPClient.fullFeed();
            } else {
                rESTClient.fullFeed();
            }
        }

        private void Form1_FormClosing(Object sender, FormClosingEventArgs e) {
            SOAPClient.Close();
        }

        private void xylosButton1_Click(object sender, EventArgs e) {

            Station[] allStations;
            if (isSOAP.Checked) {
                allStations = SOAPClient.getAllStationsIn(xylosTextBox2.Text);
            } else {
                allStations = rESTClient.getAllStationsIn(xylosTextBox2.Text);
            }

            foreach (Station item in allStations) {
                if (item.name != null) {
                    xylosCombobox1.Items.Add(item.name);
                }
            }
            showItinaryComponents();
            if (allStations.Length.Equals(0)) {
                MessageBox.Show("No stations found in " + xylosTextBox2.Text, "No stations found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void showItinaryComponents() {
            groupBox1.Visible = true;
            label2.Visible = true;
            label1.Visible = true;
            label7.Visible = true;
            xylosButton2.Visible = true;
            xylosCombobox1.Visible = true;
        }

        private void xylosCombobox1_SelectedIndexChanged(object sender, EventArgs e) {
            lblStationName.Text = xylosCombobox1.SelectedItem.ToString();

            if (isSOAP.Checked) {
                setLabelTextAsAddressFromCombobox(xylosCombobox1, lblAddress);
            } else {
                lblAddress.Text = rESTClient.getStationByName(xylosCombobox1.SelectedItem.ToString()).address;
            }
            label1.Visible = true;
        }

        private void xylosButton2_Click(object sender, EventArgs e) {
            refreshData();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            MessageBox.Show("Mail adress has been copied to clipboard ! ", "Copied", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Clipboard.SetData(DataFormats.Text, linkLabel1.Text);
        }

        private void xylosButton3_Click(object sender, EventArgs e) {

            listView1.Visible = false;
            pictureBox1.Visible = true;

            try {
                pictureBox1.Image = SOAPClient.getStaticMapImage(radioPedestrian.Checked ? true : false,
                xylosTextBox2.Text, xylosTextBox1.Text, true);
            } catch (Exception vertexError) {
                if (vertexError.Message.Contains("Failed. URL")) {
                    MessageBox.Show("The addresses you provided are too far away from each other. Google Static Maps provides a limited" +
                   " number of vertex to draw lines. We'll still provide you the informations about the route, and the details",
                   "No vertexes provided", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
        }

        private void xylosButton5_Click(object sender, EventArgs e) {
            listView1.Items.Clear();
            listView1.Visible = true;
            pictureBox1.Visible = false;
            VLib_WSSOAP_API.Step[] instructions;
            if (isSOAP.Checked) {
                instructions = SOAPClient.getInstructions(radioPedestrian.Checked ? true : false, xylosTextBox2.Text, xylosTextBox1.Text);
            } else {
                instructions = rESTClient.getInstructions(radioPedestrian.Checked ? true : false, xylosTextBox2.Text, xylosTextBox1.Text);
            }

            foreach (VLib_WSSOAP_API.Step instruction in instructions) {
                listView1.Items.Add(new ListViewItem(
                    new[] {
                        Regex.Replace(instruction.html_instructions, "<.*?>", String.Empty),
                        instruction.distance.text,
                        instruction.duration.text
                    }));
            }
        }

        private void isSOAP_CheckedChanged(object sender, EventArgs e) {
            if (isSOAP.Checked) {
                label8.Text = "Current used protocol : SOAP";
            } else {
                label8.Text = "Current used protocol : REST";
            }
            refreshData();

        }

        private void xylosButton4_Click(object sender, EventArgs e) {
            Station near = SOAPClient.getNearestStation(xylosTextBox3.Text);
            pictureBox2.Image = SOAPClient.getStaticMapImage(false, xylosTextBox3.Text, near.address + " " + near.contract_name, true);
            label16.Text = near.name;
            label17.Text = near.address;
            label18.Text = near.contract_name;
            label19.Text = near.banking ? "Yes" : "No";
            label20.Text = near.position.ToString();
            label28.Text = JCDecaux_Stations_API.timestampToDate(near.last_update).ToString();
            label29.Text = near.available_bikes.ToString();
            label30.Text = near.number.ToString();
            label31.Text = near.status.ToString().ToLower();
        }

        private void label10_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label10);
        }

        private void label18_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label18);
        }

        private void label17_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label17);
        }


        private void label16_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label16);
        }

        private void label19_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label19);
        }

        private void label20_Click(object sender, EventArgs e) {
            copyDetailFromLabel(label20);
        }

        private void copyDetailFromLabel(Label label) {
            Clipboard.SetData(DataFormats.Text, label.Text);
            MessageBox.Show("Detail been copied to clipboard ! ", "Copied", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void xylosButton6_Click(object sender, EventArgs e) {
            Station[] allStations = SOAPClient.getAllStationsIn(xylosTextBox4.Text);
            foreach (Station item in allStations) {
                if (item.name != null) {
                    xylosCombobox2.Items.Add(item.name);
                }
            }
            if (allStations.Length.Equals(0)) {
                MessageBox.Show("No stations found in " + xylosTextBox2.Text, "No stations found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void xylosButton7_Click(object sender, EventArgs e) {
            Station[] allStations = SOAPClient.getAllStationsIn(xylosTextBox5.Text);
            foreach (Station item in allStations) {
                if (item.name != null) {
                    xylosCombobox4.Items.Add(item.name);
                }
            }
            if (allStations.Length.Equals(0)) {
                MessageBox.Show("No stations found in " + xylosTextBox2.Text, "No stations found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            handleVisibleComponents();
        }

        private void xylosCombobox2_SelectedIndexChanged(object sender, EventArgs e) {
            setLabelTextAsAddressFromCombobox(xylosCombobox2, label40);
        }

        private void xylosCombobox4_SelectedIndexChanged(object sender, EventArgs e) {
            setLabelTextAsAddressFromCombobox(xylosCombobox4, label38);
            handleVisibleComponents();

            try {
                Station stationSrc = SOAPClient.getStationByName(xylosCombobox2.SelectedItem.ToString());
                Station stationDst = SOAPClient.getStationByName(xylosCombobox4.SelectedItem.ToString());
                pictureBox3.Image = SOAPClient.getStaticMapImage(isPedestrian.Checked ? true : false,
                stationSrc.address + ", " + stationSrc.contract_name,
                stationDst.address + ", " + stationDst.contract_name, true);

                initGmap();
                setGmapDatas(stationDst, stationSrc);

            } catch (Exception vertexError) {
                if (vertexError.Message.Contains("Failed. URL")) {
                    MessageBox.Show("The addresses you provided are too far away from each other. Google Static Maps provides a limited" +
                   " number of vertex to draw lines. We'll still provide you the informations about the route, and the details",
                   "No vertexes provided", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                } else {
                    MessageBox.Show("Error happened : " + vertexError.Message.ToLower(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void setGmapDatas(Station stationDst, Station stationSrc) {
            gMapControl1.Position = new PointLatLng(stationDst.position.lat, stationDst.position.lng);

            GMapMarker marker = new GMarkerGoogle(new PointLatLng(stationDst.position.lat, stationDst.position.lng), GMarkerGoogleType.orange_small);
            GMapMarker marker2 = new GMarkerGoogle(new PointLatLng(stationSrc.position.lat, stationSrc.position.lng), GMarkerGoogleType.orange_small);
            GMapOverlay markers = new GMapOverlay("markers");
            markers.Markers.Add(marker);
            markers.Markers.Add(marker2);
            gMapControl1.Overlays.Add(markers);
              

            /*      routes.Routes.Add(
                new GMapRoute(GoogleMapProvider.Instance.GetRoute(,
                new PointLatLng(stationSrc.position.lat, stationSrc.position.lng), false, false, 14).Points, "Main road"));

            gMapControl1.Overlays.Add(routes);
            */

            var route = GoogleMapProvider.Instance.GetRoute(new PointLatLng(stationSrc.position.lat, stationSrc.position.lng),
                new PointLatLng(stationDst.position.lat, stationDst.position.lng), false, false, 14);
            var r = new GMapRoute(route.Points, "My Route");

            var routes = new GMapOverlay("routes");

            routes.Routes.Add(r);
            gMapControl1.Overlays.Add(routes);

        }

        private void initGmap() {
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.MarkersEnabled = true;
            gMapControl1.ShowCenter = false;
            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.MouseWheelZoomEnabled = true;
            gMapControl1.MaxZoom = 23;
            gMapControl1.MinZoom = 0;
        }

        private void setLabelTextAsAddressFromCombobox(ComboBox combo, Label lbl) {
            lbl.Text = SOAPClient.getStationByName(combo.SelectedItem.ToString()).address;
        }


        private void xylosCheckBox1_CheckedChanged(object sender, EventArgs e) {
            handleVisibleComponents();
        }

        private void handleVisibleComponents() {
            if (shouldUseDynamicMap.Checked) {
                gMapControl1.Visible = true;
                pictureBox3.Visible = false;
            } else {
                gMapControl1.Visible = false;
                pictureBox3.Visible = true;
            }
        }
    }
}