﻿namespace VLib_Client {
    partial class Form1 {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.xylosTabControl1 = new XylosTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.isSOAP = new XylosCheckBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.xylosButton5 = new XylosButton();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.radioBike = new XylosRadioButton();
            this.radioPedestrian = new XylosRadioButton();
            this.xylosButton3 = new XylosButton();
            this.xylosTextBox1 = new XylosTextBox();
            this.lblStationName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.xylosTextBox2 = new XylosTextBox();
            this.xylosNotice1 = new XylosNotice();
            this.label2 = new System.Windows.Forms.Label();
            this.xylosCombobox1 = new XylosCombobox();
            this.xylosSeparator1 = new XylosSeparator();
            this.xylosButton1 = new XylosButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.xylosSeparator4 = new XylosSeparator();
            this.xylosButton4 = new XylosButton();
            this.xylosTextBox3 = new XylosTextBox();
            this.xylosNotice2 = new XylosNotice();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.isPedestrian = new XylosCheckBox();
            this.gMapControl1 = new GMap.NET.WindowsForms.GMapControl();
            this.shouldUseDynamicMap = new XylosCheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.xylosSeparator5 = new XylosSeparator();
            this.xylosTextBox5 = new XylosTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.xylosCombobox4 = new XylosCombobox();
            this.xylosButton7 = new XylosButton();
            this.xylosTextBox4 = new XylosTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.xylosCombobox2 = new XylosCombobox();
            this.xylosButton6 = new XylosButton();
            this.xylosNotice3 = new XylosNotice();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label41 = new System.Windows.Forms.Label();
            this.xylosSeparator6 = new XylosSeparator();
            this.xylosSeparator2 = new XylosSeparator();
            this.xylosButton2 = new XylosButton();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label42 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.xylosSeparator3 = new XylosSeparator();
            this.label33 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.xylosTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // xylosTabControl1
            // 
            this.xylosTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.xylosTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTabControl1.Controls.Add(this.tabPage1);
            this.xylosTabControl1.Controls.Add(this.tabPage3);
            this.xylosTabControl1.Controls.Add(this.tabPage4);
            this.xylosTabControl1.Controls.Add(this.tabPage2);
            this.xylosTabControl1.FirstHeaderBorder = true;
            this.xylosTabControl1.ItemSize = new System.Drawing.Size(40, 180);
            this.xylosTabControl1.Location = new System.Drawing.Point(1, 0);
            this.xylosTabControl1.Multiline = true;
            this.xylosTabControl1.Name = "xylosTabControl1";
            this.xylosTabControl1.SelectedIndex = 0;
            this.xylosTabControl1.Size = new System.Drawing.Size(626, 539);
            this.xylosTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.xylosTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.isSOAP);
            this.tabPage1.Controls.Add(this.lblAddress);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.lblStationName);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.xylosTextBox2);
            this.tabPage1.Controls.Add(this.xylosNotice1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.xylosCombobox1);
            this.tabPage1.Controls.Add(this.xylosSeparator1);
            this.tabPage1.Controls.Add(this.xylosButton1);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.tabPage1.Location = new System.Drawing.Point(184, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(438, 531);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "From bike to address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(265, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Current used protocol : SOAP";
            // 
            // isSOAP
            // 
            this.isSOAP.Checked = true;
            this.isSOAP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.isSOAP.EnabledCalc = true;
            this.isSOAP.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.isSOAP.Location = new System.Drawing.Point(15, 99);
            this.isSOAP.Name = "isSOAP";
            this.isSOAP.Size = new System.Drawing.Size(246, 18);
            this.isSOAP.TabIndex = 17;
            this.isSOAP.Text = "Using SOAP if checked. Else, using REST";
            this.isSOAP.CheckedChanged += new XylosCheckBox.CheckedChangedEventHandler(this.isSOAP_CheckedChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(118, 212);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(94, 15);
            this.lblAddress.TabIndex = 16;
            this.lblAddress.Text = "                             ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Address :";
            this.label7.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.xylosButton5);
            this.groupBox1.Controls.Add(this.listView1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.radioBike);
            this.groupBox1.Controls.Add(this.radioPedestrian);
            this.groupBox1.Controls.Add(this.xylosButton3);
            this.groupBox1.Controls.Add(this.xylosTextBox1);
            this.groupBox1.Location = new System.Drawing.Point(3, 238);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(439, 293);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Routes";
            this.groupBox1.Visible = false;
            // 
            // xylosButton5
            // 
            this.xylosButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton5.EnabledCalc = true;
            this.xylosButton5.Location = new System.Drawing.Point(309, 56);
            this.xylosButton5.Name = "xylosButton5";
            this.xylosButton5.Size = new System.Drawing.Size(116, 29);
            this.xylosButton5.TabIndex = 17;
            this.xylosButton5.Text = "Get instructions";
            this.xylosButton5.Click += new XylosButton.ClickEventHandler(this.xylosButton5_Click);
            // 
            // listView1
            // 
            this.listView1.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(-1, 90);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(434, 206);
            this.listView1.TabIndex = 18;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Instruction";
            this.columnHeader1.Width = 283;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Distance";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 67;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Duration";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 75;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(1, 91);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(432, 202);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // radioBike
            // 
            this.radioBike.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radioBike.Checked = true;
            this.radioBike.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioBike.EnabledCalc = true;
            this.radioBike.Location = new System.Drawing.Point(202, 66);
            this.radioBike.Name = "radioBike";
            this.radioBike.Size = new System.Drawing.Size(91, 18);
            this.radioBike.TabIndex = 16;
            this.radioBike.Text = "VLib (bikes)";
            // 
            // radioPedestrian
            // 
            this.radioPedestrian.Checked = false;
            this.radioPedestrian.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radioPedestrian.EnabledCalc = true;
            this.radioPedestrian.Location = new System.Drawing.Point(14, 67);
            this.radioPedestrian.Name = "radioPedestrian";
            this.radioPedestrian.Size = new System.Drawing.Size(129, 18);
            this.radioPedestrian.TabIndex = 15;
            this.radioPedestrian.Text = "Pedestrian";
            // 
            // xylosButton3
            // 
            this.xylosButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton3.EnabledCalc = true;
            this.xylosButton3.Location = new System.Drawing.Point(309, 23);
            this.xylosButton3.Name = "xylosButton3";
            this.xylosButton3.Size = new System.Drawing.Size(116, 28);
            this.xylosButton3.TabIndex = 13;
            this.xylosButton3.Text = "Get best itinary";
            this.xylosButton3.Click += new XylosButton.ClickEventHandler(this.xylosButton3_Click);
            // 
            // xylosTextBox1
            // 
            this.xylosTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTextBox1.EnabledCalc = true;
            this.xylosTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xylosTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.xylosTextBox1.Location = new System.Drawing.Point(10, 22);
            this.xylosTextBox1.MaxLength = 32767;
            this.xylosTextBox1.MultiLine = false;
            this.xylosTextBox1.Name = "xylosTextBox1";
            this.xylosTextBox1.ReadOnly = false;
            this.xylosTextBox1.Size = new System.Drawing.Size(283, 29);
            this.xylosTextBox1.TabIndex = 12;
            this.xylosTextBox1.Text = "Enter your final destination address here";
            this.xylosTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.xylosTextBox1.UseSystemPasswordChar = false;
            // 
            // lblStationName
            // 
            this.lblStationName.AutoSize = true;
            this.lblStationName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStationName.Location = new System.Drawing.Point(118, 183);
            this.lblStationName.Name = "lblStationName";
            this.lblStationName.Size = new System.Drawing.Size(94, 15);
            this.lblStationName.TabIndex = 10;
            this.lblStationName.Text = "                             ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Selected station :";
            this.label1.Visible = false;
            // 
            // xylosTextBox2
            // 
            this.xylosTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTextBox2.EnabledCalc = true;
            this.xylosTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xylosTextBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.xylosTextBox2.Location = new System.Drawing.Point(11, 57);
            this.xylosTextBox2.MaxLength = 32767;
            this.xylosTextBox2.MultiLine = false;
            this.xylosTextBox2.Name = "xylosTextBox2";
            this.xylosTextBox2.ReadOnly = false;
            this.xylosTextBox2.Size = new System.Drawing.Size(285, 31);
            this.xylosTextBox2.TabIndex = 8;
            this.xylosTextBox2.Text = "Enter your city name to list all the availables bike";
            this.xylosTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.xylosTextBox2.UseSystemPasswordChar = false;
            // 
            // xylosNotice1
            // 
            this.xylosNotice1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosNotice1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.xylosNotice1.Cursor = System.Windows.Forms.Cursors.Default;
            this.xylosNotice1.Enabled = false;
            this.xylosNotice1.Location = new System.Drawing.Point(7, 13);
            this.xylosNotice1.Multiline = true;
            this.xylosNotice1.Name = "xylosNotice1";
            this.xylosNotice1.ReadOnly = true;
            this.xylosNotice1.Size = new System.Drawing.Size(427, 31);
            this.xylosNotice1.TabIndex = 7;
            this.xylosNotice1.Text = "Here, you\'ll be able to see routes from an adress to a final destination. ";
            this.xylosNotice1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(239, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "List of every place where a bike is available : ";
            this.label2.Visible = false;
            // 
            // xylosCombobox1
            // 
            this.xylosCombobox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosCombobox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xylosCombobox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.xylosCombobox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.xylosCombobox1.EnabledCalc = true;
            this.xylosCombobox1.FormattingEnabled = true;
            this.xylosCombobox1.ItemHeight = 20;
            this.xylosCombobox1.Location = new System.Drawing.Point(255, 136);
            this.xylosCombobox1.Name = "xylosCombobox1";
            this.xylosCombobox1.Size = new System.Drawing.Size(178, 26);
            this.xylosCombobox1.TabIndex = 5;
            this.xylosCombobox1.Visible = false;
            this.xylosCombobox1.SelectedIndexChanged += new System.EventHandler(this.xylosCombobox1_SelectedIndexChanged);
            // 
            // xylosSeparator1
            // 
            this.xylosSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator1.Location = new System.Drawing.Point(13, 128);
            this.xylosSeparator1.Name = "xylosSeparator1";
            this.xylosSeparator1.Size = new System.Drawing.Size(421, 2);
            this.xylosSeparator1.TabIndex = 3;
            this.xylosSeparator1.Text = "xylosSeparator1";
            // 
            // xylosButton1
            // 
            this.xylosButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton1.EnabledCalc = true;
            this.xylosButton1.Location = new System.Drawing.Point(314, 58);
            this.xylosButton1.Name = "xylosButton1";
            this.xylosButton1.Size = new System.Drawing.Size(116, 29);
            this.xylosButton1.TabIndex = 1;
            this.xylosButton1.Text = "Get available bikes";
            this.xylosButton1.Click += new XylosButton.ClickEventHandler(this.xylosButton1_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.pictureBox2);
            this.tabPage3.Controls.Add(this.xylosSeparator4);
            this.tabPage3.Controls.Add(this.xylosButton4);
            this.tabPage3.Controls.Add(this.xylosTextBox3);
            this.tabPage3.Controls.Add(this.xylosNotice2);
            this.tabPage3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.tabPage3.Location = new System.Drawing.Point(184, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(438, 531);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Nearest bike ";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.ForeColor = System.Drawing.Color.Gray;
            this.groupBox2.Location = new System.Drawing.Point(9, 96);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(422, 153);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informations about nearest station";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(16, 132);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 15);
            this.label24.TabIndex = 0;
            this.label24.Text = "Coordonates";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label20.Location = new System.Drawing.Point(118, 133);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 15);
            this.label20.TabIndex = 0;
            this.label20.Text = "~";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(16, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "Banking around ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label19.Location = new System.Drawing.Point(118, 106);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "~";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(237, 106);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(39, 15);
            this.label32.TabIndex = 0;
            this.label32.Text = "Status";
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(237, 81);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 15);
            this.label27.TabIndex = 0;
            this.label27.Text = "Number of bikes";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(16, 81);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(28, 15);
            this.label22.TabIndex = 0;
            this.label22.Text = "City";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label18.Location = new System.Drawing.Point(118, 81);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 15);
            this.label18.TabIndex = 0;
            this.label18.Text = "~";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(237, 54);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(85, 15);
            this.label26.TabIndex = 0;
            this.label26.Text = "Available bikes";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(16, 54);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 15);
            this.label21.TabIndex = 0;
            this.label21.Text = "Address";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label17.Location = new System.Drawing.Point(118, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "~";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label31.Location = new System.Drawing.Point(359, 106);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 15);
            this.label31.TabIndex = 0;
            this.label31.Text = "~";
            this.label31.Click += new System.EventHandler(this.label16_Click);
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label30.AutoSize = true;
            this.label30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label30.Location = new System.Drawing.Point(359, 81);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "~";
            this.label30.Click += new System.EventHandler(this.label16_Click);
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label29.Location = new System.Drawing.Point(359, 54);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(15, 15);
            this.label29.TabIndex = 0;
            this.label29.Text = "~";
            this.label29.Click += new System.EventHandler(this.label16_Click);
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.AutoSize = true;
            this.label28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label28.Location = new System.Drawing.Point(359, 28);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(15, 15);
            this.label28.TabIndex = 0;
            this.label28.Text = "~";
            this.label28.Click += new System.EventHandler(this.label16_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label16.Location = new System.Drawing.Point(118, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 15);
            this.label16.TabIndex = 0;
            this.label16.Text = "~";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(237, 28);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(68, 15);
            this.label25.TabIndex = 0;
            this.label25.Text = "Last update";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 15);
            this.label15.TabIndex = 0;
            this.label15.Text = "Station name";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Crimson;
            this.label12.Location = new System.Drawing.Point(356, 472);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 15);
            this.label12.TabIndex = 6;
            this.label12.Text = "red";
            this.label12.Click += new System.EventHandler(this.label10_Click);
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(96, 472);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 15);
            this.label10.TabIndex = 6;
            this.label10.Text = "blue";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(379, 472);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 15);
            this.label13.TabIndex = 5;
            this.label13.Text = "one is ";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(112, 495);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(191, 15);
            this.label14.TabIndex = 5;
            this.label14.Text = "is pointing the nearest bike station.";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(123, 472);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(237, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "is pointing the departure address, while the ";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 472);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 15);
            this.label9.TabIndex = 5;
            this.label9.Text = "The marker in";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 260);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(432, 202);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // xylosSeparator4
            // 
            this.xylosSeparator4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator4.Location = new System.Drawing.Point(-21, 88);
            this.xylosSeparator4.Name = "xylosSeparator4";
            this.xylosSeparator4.Size = new System.Drawing.Size(488, 2);
            this.xylosSeparator4.TabIndex = 3;
            this.xylosSeparator4.Text = "xylosSeparator4";
            // 
            // xylosButton4
            // 
            this.xylosButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton4.EnabledCalc = true;
            this.xylosButton4.Location = new System.Drawing.Point(274, 53);
            this.xylosButton4.Name = "xylosButton4";
            this.xylosButton4.Size = new System.Drawing.Size(157, 29);
            this.xylosButton4.TabIndex = 2;
            this.xylosButton4.Text = "Get nearest station";
            this.xylosButton4.Click += new XylosButton.ClickEventHandler(this.xylosButton4_Click);
            // 
            // xylosTextBox3
            // 
            this.xylosTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTextBox3.EnabledCalc = true;
            this.xylosTextBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xylosTextBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.xylosTextBox3.Location = new System.Drawing.Point(6, 53);
            this.xylosTextBox3.MaxLength = 32767;
            this.xylosTextBox3.MultiLine = false;
            this.xylosTextBox3.Name = "xylosTextBox3";
            this.xylosTextBox3.ReadOnly = false;
            this.xylosTextBox3.Size = new System.Drawing.Size(262, 29);
            this.xylosTextBox3.TabIndex = 1;
            this.xylosTextBox3.Text = "Departure address";
            this.xylosTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.xylosTextBox3.UseSystemPasswordChar = false;
            // 
            // xylosNotice2
            // 
            this.xylosNotice2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosNotice2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.xylosNotice2.Cursor = System.Windows.Forms.Cursors.Default;
            this.xylosNotice2.Enabled = false;
            this.xylosNotice2.Location = new System.Drawing.Point(6, 8);
            this.xylosNotice2.Multiline = true;
            this.xylosNotice2.Name = "xylosNotice2";
            this.xylosNotice2.ReadOnly = true;
            this.xylosNotice2.Size = new System.Drawing.Size(425, 34);
            this.xylosNotice2.TabIndex = 0;
            this.xylosNotice2.Text = "You can see the nearest VLib station from any address";
            this.xylosNotice2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.isPedestrian);
            this.tabPage4.Controls.Add(this.shouldUseDynamicMap);
            this.tabPage4.Controls.Add(this.pictureBox3);
            this.tabPage4.Controls.Add(this.label40);
            this.tabPage4.Controls.Add(this.label38);
            this.tabPage4.Controls.Add(this.xylosSeparator5);
            this.tabPage4.Controls.Add(this.xylosTextBox5);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Controls.Add(this.xylosCombobox4);
            this.tabPage4.Controls.Add(this.xylosButton7);
            this.tabPage4.Controls.Add(this.xylosTextBox4);
            this.tabPage4.Controls.Add(this.label39);
            this.tabPage4.Controls.Add(this.label36);
            this.tabPage4.Controls.Add(this.label35);
            this.tabPage4.Controls.Add(this.xylosCombobox2);
            this.tabPage4.Controls.Add(this.xylosButton6);
            this.tabPage4.Controls.Add(this.xylosNotice3);
            this.tabPage4.Controls.Add(this.gMapControl1);
            this.tabPage4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.tabPage4.Location = new System.Drawing.Point(184, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(438, 531);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Route between 2 vlibs";
            // 
            // isPedestrian
            // 
            this.isPedestrian.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.isPedestrian.Checked = true;
            this.isPedestrian.Cursor = System.Windows.Forms.Cursors.Hand;
            this.isPedestrian.EnabledCalc = true;
            this.isPedestrian.Location = new System.Drawing.Point(147, 273);
            this.isPedestrian.Name = "isPedestrian";
            this.isPedestrian.Size = new System.Drawing.Size(295, 18);
            this.isPedestrian.TabIndex = 23;
            this.isPedestrian.Text = "Dispaying route as pedestrian (bike if unchecked)";
            // 
            // gMapControl1
            // 
            this.gMapControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gMapControl1.Bearing = 0F;
            this.gMapControl1.CanDragMap = true;
            this.gMapControl1.EmptyTileColor = System.Drawing.Color.Navy;
            this.gMapControl1.GrayScaleMode = false;
            this.gMapControl1.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gMapControl1.LevelsKeepInMemory = 5;
            this.gMapControl1.Location = new System.Drawing.Point(6, 328);
            this.gMapControl1.MarkersEnabled = true;
            this.gMapControl1.MaxZoom = 2;
            this.gMapControl1.MinZoom = 2;
            this.gMapControl1.MouseWheelZoomEnabled = true;
            this.gMapControl1.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapControl1.Name = "gMapControl1";
            this.gMapControl1.NegativeMode = false;
            this.gMapControl1.PolygonsEnabled = true;
            this.gMapControl1.RetryLoadTile = 0;
            this.gMapControl1.RoutesEnabled = true;
            this.gMapControl1.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gMapControl1.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gMapControl1.ShowTileGridLines = false;
            this.gMapControl1.Size = new System.Drawing.Size(432, 203);
            this.gMapControl1.TabIndex = 22;
            this.gMapControl1.Visible = false;
            this.gMapControl1.Zoom = 2D;
            // 
            // shouldUseDynamicMap
            // 
            this.shouldUseDynamicMap.Checked = true;
            this.shouldUseDynamicMap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.shouldUseDynamicMap.EnabledCalc = true;
            this.shouldUseDynamicMap.Location = new System.Drawing.Point(6, 275);
            this.shouldUseDynamicMap.Name = "shouldUseDynamicMap";
            this.shouldUseDynamicMap.Size = new System.Drawing.Size(250, 18);
            this.shouldUseDynamicMap.TabIndex = 21;
            this.shouldUseDynamicMap.Text = "Use dynamic map";
            this.shouldUseDynamicMap.CheckedChanged += new XylosCheckBox.CheckedChangedEventHandler(this.xylosCheckBox1_CheckedChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Location = new System.Drawing.Point(6, 329);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(432, 202);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 19;
            this.pictureBox3.TabStop = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(133, 132);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(18, 15);
            this.label40.TabIndex = 18;
            this.label40.Text = "~ ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(133, 234);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(18, 15);
            this.label38.TabIndex = 18;
            this.label38.Text = "~ ";
            // 
            // xylosSeparator5
            // 
            this.xylosSeparator5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator5.Location = new System.Drawing.Point(-95, 265);
            this.xylosSeparator5.Name = "xylosSeparator5";
            this.xylosSeparator5.Size = new System.Drawing.Size(810, 2);
            this.xylosSeparator5.TabIndex = 17;
            this.xylosSeparator5.Text = "xylosSeparator5";
            // 
            // xylosTextBox5
            // 
            this.xylosTextBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTextBox5.EnabledCalc = true;
            this.xylosTextBox5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xylosTextBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.xylosTextBox5.Location = new System.Drawing.Point(13, 156);
            this.xylosTextBox5.MaxLength = 32767;
            this.xylosTextBox5.MultiLine = false;
            this.xylosTextBox5.Name = "xylosTextBox5";
            this.xylosTextBox5.ReadOnly = false;
            this.xylosTextBox5.Size = new System.Drawing.Size(285, 31);
            this.xylosTextBox5.TabIndex = 16;
            this.xylosTextBox5.Text = "City of the second station (e.g toulouse)";
            this.xylosTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.xylosTextBox5.UseSystemPasswordChar = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(19, 205);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(91, 15);
            this.label37.TabIndex = 15;
            this.label37.Text = "Second station :";
            // 
            // xylosCombobox4
            // 
            this.xylosCombobox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosCombobox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xylosCombobox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.xylosCombobox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.xylosCombobox4.EnabledCalc = true;
            this.xylosCombobox4.FormattingEnabled = true;
            this.xylosCombobox4.ItemHeight = 20;
            this.xylosCombobox4.Location = new System.Drawing.Point(116, 199);
            this.xylosCombobox4.Name = "xylosCombobox4";
            this.xylosCombobox4.Size = new System.Drawing.Size(315, 26);
            this.xylosCombobox4.TabIndex = 14;
            this.xylosCombobox4.SelectedIndexChanged += new System.EventHandler(this.xylosCombobox4_SelectedIndexChanged);
            // 
            // xylosButton7
            // 
            this.xylosButton7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton7.EnabledCalc = true;
            this.xylosButton7.Location = new System.Drawing.Point(305, 158);
            this.xylosButton7.Name = "xylosButton7";
            this.xylosButton7.Size = new System.Drawing.Size(127, 29);
            this.xylosButton7.TabIndex = 13;
            this.xylosButton7.Text = "Get second station list";
            this.xylosButton7.Click += new XylosButton.ClickEventHandler(this.xylosButton7_Click);
            // 
            // xylosTextBox4
            // 
            this.xylosTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosTextBox4.EnabledCalc = true;
            this.xylosTextBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.xylosTextBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.xylosTextBox4.Location = new System.Drawing.Point(13, 60);
            this.xylosTextBox4.MaxLength = 32767;
            this.xylosTextBox4.MultiLine = false;
            this.xylosTextBox4.Name = "xylosTextBox4";
            this.xylosTextBox4.ReadOnly = false;
            this.xylosTextBox4.Size = new System.Drawing.Size(285, 31);
            this.xylosTextBox4.TabIndex = 12;
            this.xylosTextBox4.Text = "City of the first station. (e.g marseille)";
            this.xylosTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.xylosTextBox4.UseSystemPasswordChar = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(19, 132);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 15);
            this.label39.TabIndex = 11;
            this.label39.Text = "Selected station : ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 234);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(99, 15);
            this.label36.TabIndex = 11;
            this.label36.Text = "Selected station : ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(19, 103);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(74, 15);
            this.label35.TabIndex = 11;
            this.label35.Text = "First station :";
            // 
            // xylosCombobox2
            // 
            this.xylosCombobox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosCombobox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.xylosCombobox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.xylosCombobox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.xylosCombobox2.EnabledCalc = true;
            this.xylosCombobox2.FormattingEnabled = true;
            this.xylosCombobox2.ItemHeight = 20;
            this.xylosCombobox2.Location = new System.Drawing.Point(116, 99);
            this.xylosCombobox2.Name = "xylosCombobox2";
            this.xylosCombobox2.Size = new System.Drawing.Size(315, 26);
            this.xylosCombobox2.TabIndex = 10;
            this.xylosCombobox2.SelectedIndexChanged += new System.EventHandler(this.xylosCombobox2_SelectedIndexChanged);
            // 
            // xylosButton6
            // 
            this.xylosButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton6.EnabledCalc = true;
            this.xylosButton6.Location = new System.Drawing.Point(304, 60);
            this.xylosButton6.Name = "xylosButton6";
            this.xylosButton6.Size = new System.Drawing.Size(127, 29);
            this.xylosButton6.TabIndex = 9;
            this.xylosButton6.Text = "Get first station list";
            this.xylosButton6.Click += new XylosButton.ClickEventHandler(this.xylosButton6_Click);
            // 
            // xylosNotice3
            // 
            this.xylosNotice3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosNotice3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.xylosNotice3.Cursor = System.Windows.Forms.Cursors.Default;
            this.xylosNotice3.Enabled = false;
            this.xylosNotice3.Location = new System.Drawing.Point(12, 18);
            this.xylosNotice3.Multiline = true;
            this.xylosNotice3.Name = "xylosNotice3";
            this.xylosNotice3.ReadOnly = true;
            this.xylosNotice3.Size = new System.Drawing.Size(419, 28);
            this.xylosNotice3.TabIndex = 0;
            this.xylosNotice3.Text = "Here, you\'ll be able to get the path from two Vlib stations";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Controls.Add(this.xylosSeparator6);
            this.tabPage2.Controls.Add(this.xylosSeparator2);
            this.tabPage2.Controls.Add(this.xylosButton2);
            this.tabPage2.Controls.Add(this.linkLabel1);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.xylosSeparator3);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tabPage2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(133)))), ((int)(((byte)(142)))));
            this.tabPage2.Location = new System.Drawing.Point(184, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(438, 531);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Help / About";
            // 
            // label41
            // 
            this.label41.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(151, 446);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(131, 20);
            this.label41.TabIndex = 13;
            this.label41.Text = "Scenario example";
            // 
            // xylosSeparator6
            // 
            this.xylosSeparator6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator6.Location = new System.Drawing.Point(3, 444);
            this.xylosSeparator6.Name = "xylosSeparator6";
            this.xylosSeparator6.Size = new System.Drawing.Size(458, 2);
            this.xylosSeparator6.TabIndex = 12;
            this.xylosSeparator6.Text = "xylosSeparator2";
            // 
            // xylosSeparator2
            // 
            this.xylosSeparator2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator2.Location = new System.Drawing.Point(-10, 330);
            this.xylosSeparator2.Name = "xylosSeparator2";
            this.xylosSeparator2.Size = new System.Drawing.Size(458, 2);
            this.xylosSeparator2.TabIndex = 12;
            this.xylosSeparator2.Text = "xylosSeparator2";
            // 
            // xylosButton2
            // 
            this.xylosButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosButton2.EnabledCalc = true;
            this.xylosButton2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xylosButton2.Location = new System.Drawing.Point(305, 5);
            this.xylosButton2.Name = "xylosButton2";
            this.xylosButton2.Size = new System.Drawing.Size(127, 23);
            this.xylosButton2.TabIndex = 11;
            this.xylosButton2.Text = "⟳ Refresh cache datas";
            this.xylosButton2.Visible = false;
            this.xylosButton2.Click += new XylosButton.ClickEventHandler(this.xylosButton2_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Location = new System.Drawing.Point(78, 310);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(153, 15);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "valerio.kevin83@gmail.com";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label42
            // 
            this.label42.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(1, 466);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(442, 60);
            this.label42.TabIndex = 3;
            this.label42.Text = resources.GetString("label42.Text");
            this.label42.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1, 350);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(371, 90);
            this.label34.TabIndex = 3;
            this.label34.Text = resources.GetString("label34.Text");
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(367, 165);
            this.label6.TabIndex = 3;
            this.label6.Text = resources.GetString("label6.Text");
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-1, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(439, 105);
            this.label5.TabIndex = 3;
            this.label5.Text = resources.GetString("label5.Text");
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // xylosSeparator3
            // 
            this.xylosSeparator3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xylosSeparator3.Location = new System.Drawing.Point(6, 133);
            this.xylosSeparator3.Name = "xylosSeparator3";
            this.xylosSeparator3.Size = new System.Drawing.Size(458, 2);
            this.xylosSeparator3.TabIndex = 2;
            this.xylosSeparator3.Text = "xylosSeparator3";
            // 
            // label33
            // 
            this.label33.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(175, 331);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(88, 20);
            this.label33.TabIndex = 1;
            this.label33.Text = "Must-know";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(142, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Help and informations";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(193, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "About";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(628, 538);
            this.Controls.Add(this.xylosTabControl1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "JCDecaux Transport Client";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.xylosTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private XylosTabControl xylosTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private XylosSeparator xylosSeparator1;
        private XylosButton xylosButton1;
        private XylosCombobox xylosCombobox1;
        private System.Windows.Forms.Label label2;
        private XylosNotice xylosNotice1;
        private XylosTextBox xylosTextBox2;
        private System.Windows.Forms.Label lblStationName;
        private System.Windows.Forms.Label label1;
        private XylosButton xylosButton2;
        private XylosTextBox xylosTextBox1;
        private XylosSeparator xylosSeparator3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private XylosButton xylosButton3;
        private System.Windows.Forms.GroupBox groupBox1;
        private XylosRadioButton radioBike;
        private XylosRadioButton radioPedestrian;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listView1;
        private XylosButton xylosButton5;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private XylosCheckBox isSOAP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabPage tabPage3;
        private XylosSeparator xylosSeparator2;
        private XylosNotice xylosNotice2;
        private XylosButton xylosButton4;
        private XylosTextBox xylosTextBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox2;
        private XylosSeparator xylosSeparator4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private XylosNotice xylosNotice3;
        private XylosSeparator xylosSeparator5;
        private XylosTextBox xylosTextBox5;
        private System.Windows.Forms.Label label37;
        private XylosCombobox xylosCombobox4;
        private XylosButton xylosButton7;
        private XylosTextBox xylosTextBox4;
        private System.Windows.Forms.Label label35;
        private XylosCombobox xylosCombobox2;
        private XylosButton xylosButton6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label41;
        private XylosSeparator xylosSeparator6;
        private System.Windows.Forms.Label label42;
        private GMap.NET.WindowsForms.GMapControl gMapControl1;
        private XylosCheckBox shouldUseDynamicMap;
        private XylosCheckBox isPedestrian;
    }
}

