﻿using System;
using System.ServiceModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.Threading.Tasks;
using VLib_WSSOAP_API;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;

namespace JCD_WS_API {
    class Program {
        static void Main(string[] args) {
            /*
                      String __URL_SOAP__ = "http://localhost:8091/JCD_SOAP_API/API/";
                      String __URL_REST__ = "http://localhost:8091/JCD_SOAP_API/REST/";


                      ServiceHost host = new ServiceHost(typeof(VLibSoapService));


                      host.AddServiceEndpoint(typeof(IVLibSoapService), new WebHttpBinding(), __URL_REST__);
                      BasicHttpBinding binding = new BasicHttpBinding();
                      binding.MessageEncoding = WSMessageEncoding.Mtom;
                      binding.TextEncoding = Encoding.UTF8;

                      host.AddServiceEndpoint(typeof(IVLibSoapService), binding, "xx", new Uri(__URL_SOAP__));

                      host.Open();

                      Console.WriteLine("Service is host at " + DateTime.Now.ToString());
                      Console.WriteLine("URL : " + __URL_SOAP__);
                      Console.WriteLine("Host is running...");
                      Console.ReadLine();
          */

            /*            String __URL_SOAP__ = "http://localhost:8091/JCD_SOAP_API/API/";
                        String __URL_REST__ = "http://localhost:8091/JCD_SOAP_API/REST/";

                        ServiceHost host = new ServiceHost(typeof(VLibSoapService));
                        ServiceEndpoint se = host.AddServiceEndpoint(typeof(IVLibSoapService), new WebHttpBinding(), __URL_REST__, new Uri(__URL_REST__));
                        se.EndpointBehaviors.Add(new WebHttpBehavior());       
                        host.AddServiceEndpoint(typeof(IVLibSoapService), new WSHttpBinding(), __URL_SOAP__, new Uri(__URL_SOAP__));
                        host.Open();

                        Console.WriteLine("Service is host at " + DateTime.Now.ToString());
                        Console.WriteLine("URL :: " + __URL_REST__);
                        Console.WriteLine("Host is running... Press <Enter> key to stop");
                        Console.ReadLine();
                        */

             /*           String __URL__ = "http://localhost:8091/JCD_SOAP_API/API";
                        ServiceHost host = new ServiceHost(typeof(VLibSoapService), new Uri(__URL__));

                        host.AddServiceEndpoint(typeof(IVLibSoapService), new WSHttpBinding(), "");
                        ServiceEndpoint se = host.AddServiceEndpoint(typeof(IVLibSoapService), new WebHttpBinding(),
                            "http://localhost:8091/JCD_SOAP_API/REST", new Uri("http://localhost:8091/JCD_SOAP_API/REST"));


                        se.EndpointBehaviors.Add(new WebHttpBehavior());
                        ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                        smb.HttpGetEnabled = true;
                        host.Description.Behaviors.Add(smb);
                        host.Description.Behaviors.Remove(typeof(ServiceDebugBehavior));
                        host.Description.Behaviors.Add(new ServiceDebugBehavior { IncludeExceptionDetailInFaults = true });
                        host.Open();  */

            ServiceHost serviceHost = new ServiceHost(typeof(VLibSoapService));
       
            serviceHost.Open();

            Console.WriteLine("Server : SOAP API");
            Console.WriteLine("Service is host at " + DateTime.Now.ToString());
            Console.WriteLine("URL : " + "http://localhost:8091/JCD_SOAP_API/API");
            Console.WriteLine("Host is running... Press <Enter> key to stop");
            Console.ReadLine(); 
        }
    }
}